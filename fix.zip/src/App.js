import React from 'react';
import { DraggableList } from './components/list';

function App() {
  return (
    <DraggableList/>
  );
}

export default App;
